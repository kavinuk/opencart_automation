from playwright.sync_api import sync_playwright,Page
class LoginPage:
    def __init__(self,page):
        self.page = page

        #locators
        self.txt_email_address = page.locator('#input-email')
        self.txt_password = page.locator('#input-password')
        self.btn_login = page.locator("input[value='Login']")
        self.txt_error_message  = page.locator(".alert.alert-danger.alert-dismissible")

        #action details


    def set_email(self,email:str):
        try:
            self.txt_email_address.fill(email)
        except Exception as e:
            print(f"Exception while entering email: {e}")
            raise

    def set_password(self,password:str):
        try:
            self.txt_password.fill(password)
        except Exception as e:
            print(f"Exception while entering password: {e}")
            raise

    def click_login(self):
        try:
            self.btn_login.click()
        except Exception as e:
            print(f"Exception while clicking login button : {e}")

    def login(self,email:str,password:str):
        self.set_email(email)
        self.set_password(password)
        self.click_login()


    def get_login_error(self):
        try:
            return self.txt_error_message
        except Exception as e:
            print(f"Exception while fetching login error message: {e}")
            return None



